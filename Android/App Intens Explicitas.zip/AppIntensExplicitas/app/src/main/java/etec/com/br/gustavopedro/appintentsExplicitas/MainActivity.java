package etec.com.br.gustavopedro.appintentsExplicitas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //OBJETOS PARA REFERENCIAR
    Button btT2, btT3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //REFERENCIANDO
        btT2 = findViewById(R.id.btnT2);
        btT3 = findViewById(R.id.btnT3);

        //BOTÃO DA TELA2
        btT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CRIAR A INTENT PARA ABRIR A TELA 2
                Intent abrirTela2 = new Intent(MainActivity.this,Tela2.class);
                startActivity(abrirTela2);
            }
        });

        //BOTÃO DA TELA3
        btT3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CRIAR INTENT TELA 3
                Intent abrirTela3 = new Intent(MainActivity.this,Tela3.class);
                startActivity(abrirTela3);
            }
        });
    }

    @Override
    public void onBackPressed() {
    }

}