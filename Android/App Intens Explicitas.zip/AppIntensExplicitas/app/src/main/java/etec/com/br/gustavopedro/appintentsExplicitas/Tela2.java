package etec.com.br.gustavopedro.appintentsExplicitas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {
    //REFERENCIANDO OS OBJETOS
    Button btnVoltarT2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        //REFEREMCIANDO TUCTUCTU TA
        btnVoltarT2 = findViewById(R.id.btnvoltarT2);

        //O OTO BOTÃO VOLTAR TELA2
        btnVoltarT2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CRIRAR A INTENT PARA VOLTAR PARA A TELA MAIN ACTIVITY
                //CONSTRUIR A MENSAGEM
                AlertDialog.Builder mensagem = new AlertDialog.Builder(Tela2.this);
                //TITULO DA MENSAGEM
                mensagem.setTitle("Confirmar");
                //TEXTO DA MENSAGEM
                mensagem.setMessage("Deseja Voltar?");
                //BOTÃO SIM (COM AÇÃO - LISTENER)
                mensagem.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //FINALIZA A TELA 2
                        finish();
                    }
                });
                //BOTÃO NÃO SEM LISTENER
                mensagem.setNegativeButton("Não", null);
                //PARA NÃO FECHAR QUANDO CLICAR FORA
                mensagem.setCancelable(false);
                //ÍCONE DA MENSAGEM NA PASTA DRAWABLE
                mensagem.setIcon(R.drawable.i);
                //MOSTRAR A MENSAGEM
                mensagem.show();
            }
        });
    }
    //BLOQUEAR O VOLTAR DO CELULAR
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique do Voltar do app", Toast.LENGTH_SHORT).show();
    }
}