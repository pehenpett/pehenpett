package etec.com.br.gustavopedro.appintentsExplicitas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Tela3 extends AppCompatActivity {
    Button btnVoltarT3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);
        //REFERENCIANDO
        btnVoltarT3 = findViewById(R.id.btnvoltarT3);

        //BOTÃO VOLTAR TELA3
        btnVoltarT3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CRIAR A INTENT PARA VOLTAR PARA A MAIN ACTIVITY? TALVEZ NUM SEI
                //CONSTRUIR A MENSAGEM
                AlertDialog.Builder mensagem = new AlertDialog.Builder(Tela3.this);
                //TITULO DA MENSAGEM
                mensagem.setTitle("Confirmar");
                //TEXTO DA MENSAGEM
                mensagem.setMessage("Deseja Voltar?");
                //BOTÃO SIM (COM AÇÃO - LISTENER)
                mensagem.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //FINALIZA A TELA 3
                        finish();
                    }
                });
                //BOTÃO NÃO SEM LISTENER
                mensagem.setNegativeButton("Não", null);
                //PARA NÃO FECHAR QUANDO CLICAR FORA
                mensagem.setCancelable(false);
                //ÍCONE DA MENSAGEM NA PASTA DRAWABLE
                mensagem.setIcon(R.drawable.i);
                //MOSTRAR A MENSAGEM
                mensagem.show();
            }
        });
    }
    //Bloquear o voltar

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no Voltar do app", Toast.LENGTH_SHORT).show();
    }
}