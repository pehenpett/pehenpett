package etec.com.br.pedropetrelliarthur.appintentparametros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    //objetos para referenciar
    EditText edNome,edEmail;
    Button btCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //referenciando
        edNome = findViewById(R.id.edtNome);
        edEmail = findViewById(R.id.edtEmail);
        btCadastrar = findViewById(R.id.btnCadastrar);

        //botão cadastrar
        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //variaveis auxiliares
                String nome,email;

                //verificando se o nome está vazio
                if (edNome.getText().toString().isEmpty()){
                    edNome.setError("Nome obrigatório");
                    edNome.requestFocus();
                }
                //verificando se o e-mail está vazio
                else if (edEmail.getText().toString().isEmpty()) {
                    edEmail.setError("E-mail é obrigatório");
                    edEmail.requestFocus();
                }
                //verificando se não é um email (! indica um não)
                else if (!edEmail.getText().toString().contains("@")) {
                    edEmail.setError("E-mail inválido");
                    edEmail.requestFocus();
                }
                //caso todas estiverem falsas
                else{
                    //recuperar dados para enviar para outra tela
                    nome = edNome.getText().toString();
                    email = edEmail.getText().toString();

                    //construindo a intent para chamar a outra tela
                    Intent abrirTela2 = new Intent(MainActivity.this, tela2.class);

                    //enviando as info para a outra tela
                    abrirTela2.putExtra("nome",nome);
                    abrirTela2.putExtra("email",email);
                    //executar a abertura da tela
                    startActivity(abrirTela2);
                }

            }
        });
    }
}