package etec.com.br.pedropetrelliarthur.appintentparametros;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class tela2 extends AppCompatActivity {
    //objetos para referenciar
    TextView txNome,txEmail;
    Button btVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        //referenciando
        txNome = findViewById(R.id.txtNome);
        txEmail = findViewById(R.id.txtEmail);
        btVoltar = findViewById(R.id.btnVoltar);

        //criar a intent para gruardar
        //usar get intent
        Intent telaAtual = getIntent();
        //criar ym bundle para acessar a intent0 e ler as info
        //usat getExtras()

        Bundle dados = telaAtual.getExtras();
        //variaveis auxiliares
        String nomeRecebido, emailRecebido;
        //usar o getString() para separar as info
        nomeRecebido = dados.getString("nome");
        emailRecebido = dados.getString("email");
        //exibir
        txNome.setText(nomeRecebido);
        txEmail.setText(emailRecebido);
    }
}