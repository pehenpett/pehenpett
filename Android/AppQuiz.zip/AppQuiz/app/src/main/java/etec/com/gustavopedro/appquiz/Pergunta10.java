package etec.com.gustavopedro.appquiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class Pergunta10 extends AppCompatActivity {

    RadioGroup rGroup;

    Button btEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perguntaz10);
        rGroup = findViewById(R.id.rdGroup);
        btEnviar = findViewById(R.id.btn_Enviar);


        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        String Nome;


        Nome = dados.getString("Nome");
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int Fptc;
                Fptc = dados.getInt("Fptc");

                Intent TelaFinal = new Intent(Pergunta10.this, TelaFinal.class);

                int op, ptc = 0;

                op = rGroup.getCheckedRadioButtonId();

                if (op==R.id.rdb1){
                    ptc+=1;
                }
                else{
                    ptc+=0;
                }

               Fptc+=ptc;

                TelaFinal.putExtra("Nome",Nome);
                TelaFinal.putExtra("Fptc", Fptc);
                startActivity(TelaFinal);
            }
        });
    }
}