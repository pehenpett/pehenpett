package etec.com.gustavopedro.appquiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class Pergunta7 extends AppCompatActivity {

    RadioGroup rGroup;

    Button btEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta7);
        rGroup = findViewById(R.id.rdGroup);
        btEnviar = findViewById(R.id.btn_Enviar);


        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        String Nome;


        Nome = dados.getString("Nome");
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int Fptc;
                Fptc = dados.getInt("Fptc");

                Intent Pergunta8 = new Intent(Pergunta7.this, Pergunta8.class);

                int op, ptc = 0;

                op = rGroup.getCheckedRadioButtonId();

                if (op==R.id.rdb4){
                    ptc+=1;
                }
                else{
                    ptc+=0;
                }

               Fptc+=ptc;

                Pergunta8.putExtra("Nome",Nome);
                Pergunta8.putExtra("Fptc", Fptc);
                startActivity(Pergunta8);
            }
        });
    }
}