package etec.com.gustavopedro.appquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class TelaFinal extends AppCompatActivity {

    TextView txPtc;
    Button btVoltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_final);
        txPtc = findViewById(R.id.txt_Ptc);


        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        int Fptc2;

        Fptc2 = dados.getInt("Fptc");

        txPtc.setText(Fptc2);

    }
}