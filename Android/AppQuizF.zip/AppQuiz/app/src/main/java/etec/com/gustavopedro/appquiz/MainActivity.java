package etec.com.gustavopedro.appquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edNome;

    Button btIniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edNome = findViewById(R.id.edt_Nome);
        btIniciar = findViewById(R.id.btn_Iniciar);

        btIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Nome;
                if (edNome.getText().toString().isEmpty()){
                    edNome.setError("Nome Obrigatorio");
                }
                else {
                    Nome = edNome.getText().toString();
                    Intent Pergunta1 = new Intent(MainActivity.this, Pergunta1.class);
                    Pergunta1.putExtra("Nome",Nome);
                    startActivity(Pergunta1);
                }
            }
        });
    }
}