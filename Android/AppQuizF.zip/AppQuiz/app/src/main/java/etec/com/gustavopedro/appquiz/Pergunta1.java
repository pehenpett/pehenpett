package etec.com.gustavopedro.appquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Pergunta1 extends AppCompatActivity {

    RadioGroup rGroup;

    Button btEnviar;

    TextView NomeU;

    int op, ptc = 0, fptc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta1);
        rGroup = findViewById(R.id.rdGroup);
        btEnviar = findViewById(R.id.btn_Enviar);
        NomeU = findViewById(R.id.txt_Nome);


        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        String Nome;

        Nome = dados.getString("Nome");

        NomeU.setText(Nome);
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                op = rGroup.getCheckedRadioButtonId();

                if (rGroup.getCheckedRadioButtonId() == -1){
                    Toast.makeText(Pergunta1.this, "Selecione uma opção", Toast.LENGTH_LONG).show();
                }
                else if (op==R.id.rdb4){
                    ptc+=1;

                    fptc = ptc + fptc;

                    Intent Pergunta2 = new Intent(Pergunta1.this, Pergunta2.class);
                    Pergunta2.putExtra("Nome",Nome);
                    Pergunta2.putExtra("Fptc",fptc);

                    finish();
                    startActivity(Pergunta2);
                }
                else{

                    ptc+=0;

                    fptc = ptc + fptc;

                    Intent Pergunta2 = new Intent(Pergunta1.this, Pergunta2.class);
                    Pergunta2.putExtra("Nome",Nome);
                    Pergunta2.putExtra("Fptc",fptc);

                    finish();
                    startActivity(Pergunta2);
                }
            }
        });

    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no botão voltar do app", Toast.LENGTH_SHORT).show();
    }
}