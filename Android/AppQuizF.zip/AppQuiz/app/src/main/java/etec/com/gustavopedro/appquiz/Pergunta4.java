package etec.com.gustavopedro.appquiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Pergunta4 extends AppCompatActivity {

    RadioGroup rGroup;

    Button btEnviar;

    TextView NomeU;

    int op, ptc = 0, Fptc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta4);
        rGroup = findViewById(R.id.rdGroup);
        btEnviar = findViewById(R.id.btn_Enviar);
        NomeU = findViewById(R.id.txt_Nome);

        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        String Nome;


        Nome = dados.getString("Nome");
        NomeU.setText(Nome);
        Fptc = dados.getInt("Fptc");
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {





                op = rGroup.getCheckedRadioButtonId();

                if (rGroup.getCheckedRadioButtonId() == -1){
                    Toast.makeText(Pergunta4.this, "Selecione uma opção", Toast.LENGTH_LONG).show();
                }
                else if (op==R.id.rdb1){
                    ptc+=1;

                    Fptc = ptc + Fptc;

                    Intent Pergunta5 = new Intent(Pergunta4.this, Pergunta5.class);
                    Pergunta5.putExtra("Nome",Nome);
                    Pergunta5.putExtra("Fptc",Fptc);
                    ;
                    finish();
                    startActivity(Pergunta5);
                }
                else{

                    ptc+=0;

                    Fptc = ptc + Fptc;

                    Intent Pergunta5 = new Intent(Pergunta4.this, Pergunta5.class);
                    Pergunta5.putExtra("Nome",Nome);
                    Pergunta5.putExtra("Fptc",Fptc);

                    finish();
                    startActivity(Pergunta5);
                }
            }
        });
    }
}