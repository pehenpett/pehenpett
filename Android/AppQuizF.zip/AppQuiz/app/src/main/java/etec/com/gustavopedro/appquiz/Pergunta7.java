package etec.com.gustavopedro.appquiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Pergunta7 extends AppCompatActivity {

    RadioGroup rGroup;

    Button btEnviar;

    TextView NomeU;

    int op, ptc = 0, Fptc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta7);
        rGroup = findViewById(R.id.rdGroup);
        btEnviar = findViewById(R.id.btn_Enviar);
        NomeU = findViewById(R.id.txt_Nome);

        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        String Nome;


        Nome = dados.getString("Nome");
        NomeU.setText(Nome);
        Fptc = dados.getInt("Fptc");
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                op = rGroup.getCheckedRadioButtonId();

                if (rGroup.getCheckedRadioButtonId() == -1){
                    Toast.makeText(Pergunta7.this, "Selecione uma opção", Toast.LENGTH_LONG).show();
                }
                else if (op==R.id.rdb4){
                    ptc+=1;

                    Fptc = ptc + Fptc;

                    Intent Pergunta7 = new Intent(Pergunta7.this, Pergunta8.class);
                    Pergunta7.putExtra("Nome",Nome);
                    Pergunta7.putExtra("Fptc",Fptc);
                    ;
                    finish();
                    startActivity(Pergunta7);
                }
                else{

                    ptc+=0;

                    Fptc = ptc + Fptc;

                    Intent Pergunta7 = new Intent(Pergunta7.this, Pergunta8.class);
                    Pergunta7.putExtra("Nome",Nome);
                    Pergunta7.putExtra("Fptc",Fptc);

                    finish();
                    startActivity(Pergunta7);
                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no botão voltar do app", Toast.LENGTH_SHORT).show();
    }
}