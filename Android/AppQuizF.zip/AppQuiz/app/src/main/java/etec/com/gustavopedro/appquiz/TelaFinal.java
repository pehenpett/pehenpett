package etec.com.gustavopedro.appquiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class TelaFinal extends AppCompatActivity {

    TextView txPtc;
    Button btVoltar;
    String Fptc2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_final);
        txPtc = findViewById(R.id.txt_Ptc);
        btVoltar = findViewById(R.id.btnReiniciar);


        Intent telaAtual = getIntent();

        Bundle dados = telaAtual.getExtras();

        Fptc2 = String.valueOf(dados.getInt("Fptc"));

        txPtc.setText(Fptc2);
        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no botão voltar do app", Toast.LENGTH_SHORT).show();
    }
}
