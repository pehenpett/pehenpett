package etec.com.br.gustavopedro.pesoideal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    //REFERENCIANDO OBJETOS
    Button btnF, btnM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnF = findViewById(R.id.btF);
        btnM = findViewById(R.id.btM);

        btnF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abrirtelaF = new Intent(MainActivity.this,TelaF.class);
                startActivity(abrirtelaF);
            }
        });

        btnM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AbrirtelaM = new Intent(MainActivity.this,TelaM.class);
                startActivity(AbrirtelaM);
            }
        });
    }
}