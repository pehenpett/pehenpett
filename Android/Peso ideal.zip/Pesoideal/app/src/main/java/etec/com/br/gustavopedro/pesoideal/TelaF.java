package etec.com.br.gustavopedro.pesoideal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TelaF extends AppCompatActivity {

        Button btnCalcF, btnVoltarF;
        EditText edtF;

        float  val1, resp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_f);
        btnCalcF = findViewById(R.id.btcalcF);
        btnVoltarF = findViewById(R.id.btVoltarF);
        edtF = findViewById(R.id.edtAlturaF);

        //buttoncalcF
        btnCalcF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtF.getText().toString().isEmpty()){
                    edtF.setError("Nenhum valor inserido");
                    edtF.requestFocus();
                }
                else{
                    val1 = Float.parseFloat(edtF.getText().toString());
                    resp = 62.1f * val1 - 44.7f;
                    Toast.makeText(TelaF.this, "A conversão é " +(resp), Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnVoltarF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mensagem = new AlertDialog.Builder(TelaF.this);
                mensagem.setTitle("Confirmar");
                mensagem.setMessage("Deseja Voltar?");
                mensagem.setPositiveButton("sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                });
                mensagem.setNegativeButton("Não", null);
                mensagem.setCancelable(false);
                mensagem.show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no Voltar do app", Toast.LENGTH_SHORT).show();
    }
}