package etec.com.br.gustavopedro.pesoideal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TelaM extends AppCompatActivity {

    Button btnCalcM, btnVoltarM;

    EditText edtM;

    float val1, resp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_m);
        btnCalcM = findViewById(R.id.btCalcM);
        btnVoltarM = findViewById(R.id.btVoltarM);
        edtM = findViewById(R.id.edtAlturaM);

        //Button
        btnCalcM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtM.getText().toString().isEmpty()){
                    edtM.setError("Nenhum valor inserido");
                    edtM.requestFocus();
                }
                else{
                    val1 = Float.parseFloat(edtM.getText().toString());
                    resp = 72.7f * val1 - 58f;
                    Toast.makeText(TelaM.this, "A conversão é "+(resp), Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnVoltarM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mensagem = new AlertDialog.Builder(TelaM.this);
                mensagem.setTitle("Confirmar");
                mensagem.setMessage("Deseja Voltar?");
                mensagem.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                });
                mensagem.setNegativeButton("Não", null);
                mensagem.setCancelable(false);
                mensagem.show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Clique no Voltar do app", Toast.LENGTH_SHORT).show();
    }
}